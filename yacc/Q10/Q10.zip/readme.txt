operate the calculator as follows :

1. Each statement is terminated by \n

2. use single character varibles to store values:
a=32;
A=1;
B=2;

3. then perform operations,
a+B+A

4. the result is auto displayed

5. to display a variables, write its name
a
A

6. type "exit" to exit the calculator
